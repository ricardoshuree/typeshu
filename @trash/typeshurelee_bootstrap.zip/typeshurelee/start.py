"""
start.py — TypeMarkLee Environment Starter
==========================================
Orquestra a inicialização completa do ambiente de desenvolvimento:

  1. Verifica Python, Node.js, npm e uv
  2. Instala dependências do MCP (uv sync em mcp-local/)
  3. Instala dependências do app (npm install)
  4. Verifica se o servidor MCP está registrado no Claude Desktop
  5. Inicia o servidor MCP em background (via uv run)
  6. Exibe instruções para iniciar o monitor e o app

Uso:
  python start.py          → inicialização completa
  python start.py --check  → apenas verifica o ambiente, sem subir nada
  python start.py --mcp    → só sobe o servidor MCP
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ── Constantes ──────────────────────────────────────────────────────────────────
ROOT        = Path(__file__).parent.resolve()
MCP_DIR     = ROOT / "mcp-local"
MCP_SERVER  = MCP_DIR / "server.py"
MCP_NAME    = "mcp-typeshurelee"
MIN_NODE    = (18, 0)
MIN_PYTHON  = (3, 11)

IS_WIN = platform.system() == "Windows"

# Cores ANSI
R   = "\033[0m"
G   = "\x1b[38;5;82m"
RD  = "\x1b[38;5;160m"
AM  = "\x1b[38;5;208m"
CY  = "\x1b[38;5;39m"
BD  = "\x1b[1m"
DIM = "\x1b[2m"

if IS_WIN:
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleMode(ctypes.windll.kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass


def ok(msg: str):  print(f"  {G}✓{R}  {msg}")
def err(msg: str): print(f"  {RD}✗{R}  {msg}")
def warn(msg: str):print(f"  {AM}!{R}  {msg}")
def info(msg: str):print(f"  {CY}→{R}  {msg}")
def hdr(msg: str): print(f"\n{BD}{msg}{R}")


# ── Verificações ────────────────────────────────────────────────────────────────

def check_python() -> bool:
    v = sys.version_info
    if (v.major, v.minor) >= MIN_PYTHON:
        ok(f"Python {v.major}.{v.minor}.{v.micro}")
        return True
    err(f"Python {v.major}.{v.minor} — mínimo exigido: {MIN_PYTHON[0]}.{MIN_PYTHON[1]}")
    return False


def check_node() -> bool:
    node = shutil.which("node")
    if not node:
        err("Node.js não encontrado — instale em https://nodejs.org (>=18)")
        return False
    try:
        out = subprocess.check_output(["node", "--version"], text=True).strip()
        parts = out.lstrip("v").split(".")
        major, minor = int(parts[0]), int(parts[1])
        if (major, minor) >= MIN_NODE:
            ok(f"Node.js {out}")
            return True
        err(f"Node.js {out} — mínimo exigido: v{MIN_NODE[0]}.{MIN_NODE[1]}")
        return False
    except Exception as e:
        err(f"Erro ao verificar Node.js: {e}")
        return False


def check_npm() -> bool:
    npm = shutil.which("npm")
    if not npm:
        err("npm não encontrado")
        return False
    try:
        out = subprocess.check_output(["npm", "--version"], text=True).strip()
        ok(f"npm v{out}")
        return True
    except Exception as e:
        err(f"Erro ao verificar npm: {e}")
        return False


def check_uv() -> bool:
    uv = shutil.which("uv")
    if not uv:
        warn("uv não encontrado — instalando via pip...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "uv", "-q"])
            ok("uv instalado")
            return True
        except Exception as e:
            err(f"Falha ao instalar uv: {e}")
            return False
    try:
        out = subprocess.check_output(["uv", "--version"], text=True).strip()
        ok(f"uv {out}")
        return True
    except Exception as e:
        err(f"Erro ao verificar uv: {e}")
        return False


def check_claude_desktop() -> bool:
    """Verifica se o MCP está registrado no claude_desktop_config.json."""
    config_paths = []
    if IS_WIN:
        appdata = os.environ.get("APPDATA", "")
        config_paths.append(Path(appdata) / "Claude" / "claude_desktop_config.json")
    else:
        config_paths.append(Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json")
        config_paths.append(Path.home() / ".config" / "claude" / "claude_desktop_config.json")

    for cfg_path in config_paths:
        if cfg_path.exists():
            try:
                cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
                servers = cfg.get("mcpServers", {})
                if MCP_NAME in servers:
                    ok(f"MCP '{MCP_NAME}' registrado no Claude Desktop")
                    return True
                warn(f"MCP '{MCP_NAME}' NÃO registrado em {cfg_path}")
                _print_mcp_config_hint(cfg_path)
                return False
            except Exception as e:
                warn(f"Erro ao ler {cfg_path}: {e}")
    warn("claude_desktop_config.json não encontrado — Claude Desktop instalado?")
    _print_mcp_config_hint(None)
    return False


def _print_mcp_config_hint(cfg_path):
    uv_path = shutil.which("uv") or "uv"
    server_path = str(MCP_SERVER).replace("\\", "/")
    mcp_dir_path = str(MCP_DIR).replace("\\", "/")
    print()
    info("Adicione ao claude_desktop_config.json:")
    snippet = {
        "mcpServers": {
            MCP_NAME: {
                "command": uv_path,
                "args": ["run", "--project", mcp_dir_path, server_path]
            }
        }
    }
    print(f"\n{DIM}{json.dumps(snippet, indent=2)}{R}\n")


# ── Instalação de dependências ───────────────────────────────────────────────────

def install_mcp_deps() -> bool:
    hdr("Instalando dependências do MCP (uv sync)...")
    try:
        subprocess.check_call(
            ["uv", "sync"],
            cwd=str(MCP_DIR),
        )
        ok("Dependências do MCP instaladas")
        return True
    except subprocess.CalledProcessError as e:
        err(f"Falha no uv sync: {e}")
        return False


def install_npm_deps() -> bool:
    pkg_json = ROOT / "package.json"
    if not pkg_json.exists():
        warn("package.json não encontrado — npm install pulado (app ainda não scaffolado)")
        return True
    hdr("Instalando dependências do app (npm install)...")
    try:
        subprocess.check_call(["npm", "install"], cwd=str(ROOT))
        ok("node_modules instalado")
        return True
    except subprocess.CalledProcessError as e:
        err(f"Falha no npm install: {e}")
        return False


# ── Iniciar MCP ──────────────────────────────────────────────────────────────────

def start_mcp() -> subprocess.Popen | None:
    hdr("Iniciando servidor MCP...")
    try:
        uv = shutil.which("uv") or "uv"
        proc = subprocess.Popen(
            [uv, "run", str(MCP_SERVER)],
            cwd=str(MCP_DIR),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.5)
        if proc.poll() is None:
            ok(f"Servidor MCP iniciado (PID {proc.pid})")
            return proc
        err("Servidor MCP encerrou imediatamente — verifique mcp-local/server.py")
        return None
    except Exception as e:
        err(f"Falha ao iniciar MCP: {e}")
        return None


# ── Main ─────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="TypeMarkLee — inicializador de ambiente")
    parser.add_argument("--check", action="store_true", help="Apenas verifica o ambiente")
    parser.add_argument("--mcp",   action="store_true", help="Só inicia o servidor MCP")
    args = parser.parse_args()

    print(f"\n{BD}{'─' * 55}{R}")
    print(f"{BD}  TypeMarkLee — Inicializador de Ambiente{R}")
    print(f"{BD}{'─' * 55}{R}")

    hdr("Verificando dependências do sistema...")
    py_ok   = check_python()
    node_ok = check_node()
    npm_ok  = check_npm()
    uv_ok   = check_uv()

    hdr("Verificando registro no Claude Desktop...")
    claude_ok = check_claude_desktop()

    if args.check:
        print()
        all_ok = py_ok and node_ok and npm_ok and uv_ok
        if all_ok:
            ok("Ambiente OK")
        else:
            err("Ambiente com problemas — corrija os itens acima")
        return

    if not (py_ok and uv_ok):
        err("Pré-requisitos mínimos não atendidos — corrija antes de continuar")
        sys.exit(1)

    if args.mcp:
        proc = start_mcp()
        if proc:
            print(f"\n{DIM}Servidor MCP rodando. Ctrl+C para encerrar.{R}")
            try:
                proc.wait()
            except KeyboardInterrupt:
                proc.terminate()
        return

    # Fluxo completo
    install_mcp_deps()
    install_npm_deps()
    proc = start_mcp()

    print(f"\n{BD}{'─' * 55}{R}")
    print(f"{BD}  Ambiente pronto!{R}")
    print(f"{BD}{'─' * 55}{R}")
    if not claude_ok:
        warn("Registre o MCP no Claude Desktop (instruções acima) e reinicie o app")
    info("Para monitorar o MCP:  python monitor_mcp.py")
    if (ROOT / "package.json").exists():
        info("Para rodar o app:      npm run dev")
    else:
        info("Próximo passo: scaffoldar o app (npm init + Electron/Vite)")
    print()

    if proc:
        print(f"{DIM}Servidor MCP rodando (PID {proc.pid}). Ctrl+C para encerrar.{R}\n")
        try:
            proc.wait()
        except KeyboardInterrupt:
            print(f"\n{AM}Encerrando servidor MCP...{R}")
            proc.terminate()


if __name__ == "__main__":
    main()
